# Photo Gallery
> A photo gallery application with mobile and web clients. Developed by John Matson, Raymond Bedry, Arbab Ahmed and Jonathan Oliveros in spring 2021 for BCIT's COMP 7855, taught by Tejinder Randhawa.
